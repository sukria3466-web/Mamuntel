import * as THREE from 'three';
import * as xb from 'xrblocks';
import { autoResponder } from '../services/autoResponder';

export class SpatialCommandCenter extends xb.Script {
  private serverGroup: THREE.Group = new THREE.Group();
  private rings: THREE.Mesh[] = [];
  private coreOrb: THREE.Mesh | null = null;
  private coreMaterial: THREE.MeshStandardMaterial | null = null;
  private phoneGroup: THREE.Group = new THREE.Group();
  private phoneScreenCanvas: HTMLCanvasElement | null = null;
  private phoneScreenTexture: THREE.CanvasTexture | null = null;
  private statusText: xb.UIText | null = null;
  private latestLogText: xb.UIText | null = null;
  private modeText: xb.UIText | null = null;
  private card: xb.UICard | null = null;
  private unsubscribe: (() => void) | null = null;
  private timeElapsed: number = 0;

  init() {
    try {
      this.add(new THREE.HemisphereLight(0xffeedd, 0x111122, 2.5));

      const dirLight = new THREE.DirectionalLight(0xffd700, 2);
      dirLight.position.set(2, 4, 2);
      this.add(dirLight);

      const greenPointLight = new THREE.PointLight(0x00e676, 3, 4);
      greenPointLight.position.set(0, 1.2, -1.2);
      this.add(greenPointLight);

      this.buildServerTerminal();
      this.buildHolographicPhone();
      this.buildSpatialUi();

      this.unsubscribe = autoResponder.subscribe(() => {
        this.refreshState();
      });
      this.refreshState();
    } catch (err) {
      console.warn('SpatialCommandCenter init safe notice:', err);
    }
  }

  private buildServerTerminal() {
    this.serverGroup.position.set(0, 0.9, -1.3);

    const baseGeo = new THREE.CylinderGeometry(0.35, 0.45, 0.15, 32);
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x141419,
      metalness: 0.85,
      roughness: 0.25,
    });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.y = -0.5;
    this.serverGroup.add(baseMesh);

    const trimGeo = new THREE.TorusGeometry(0.4, 0.015, 16, 64);
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      metalness: 0.95,
      roughness: 0.15,
      emissive: 0x553e00,
    });
    const trimMesh = new THREE.Mesh(trimGeo, goldMat);
    trimMesh.rotation.x = Math.PI / 2;
    trimMesh.position.y = -0.42;
    this.serverGroup.add(trimMesh);

    const orbGeo = new THREE.SphereGeometry(0.12, 32, 32);
    this.coreMaterial = new THREE.MeshStandardMaterial({
      color: 0x00e676,
      emissive: 0x00e676,
      emissiveIntensity: 0.8,
      roughness: 0.1,
    });
    this.coreOrb = new THREE.Mesh(orbGeo, this.coreMaterial);
    this.coreOrb.position.y = 0;
    this.serverGroup.add(this.coreOrb);

    const ringRadii = [0.22, 0.28, 0.34];
    ringRadii.forEach((r, idx) => {
      const ringGeo = new THREE.TorusGeometry(r, 0.008, 16, 64);
      const ringMesh = new THREE.Mesh(ringGeo, goldMat);
      ringMesh.rotation.x = (idx * Math.PI) / 3;
      ringMesh.rotation.y = (idx * Math.PI) / 4;
      this.rings.push(ringMesh);
      this.serverGroup.add(ringMesh);
    });

    for (let i = 0; i < 4; i++) {
      const angle = (i * Math.PI) / 2;
      const pillarGeo = new THREE.BoxGeometry(0.04, 0.7, 0.04);
      const pillar = new THREE.Mesh(pillarGeo, baseMat);
      pillar.position.set(Math.cos(angle) * 0.42, -0.15, Math.sin(angle) * 0.42);
      this.serverGroup.add(pillar);
    }

    this.add(this.serverGroup);
  }

  private buildHolographicPhone() {
    this.phoneGroup.position.set(0.55, 1.35, -1.1);
    this.phoneGroup.rotation.y = -0.35;

    const phoneGeo = new THREE.BoxGeometry(0.18, 0.34, 0.016);
    const phoneBodyMat = new THREE.MeshStandardMaterial({
      color: 0x0a0a0c,
      metalness: 0.9,
      roughness: 0.2,
    });
    const phoneMesh = new THREE.Mesh(phoneGeo, phoneBodyMat);
    this.phoneGroup.add(phoneMesh);

    const edgeGeo = new THREE.BoxGeometry(0.184, 0.344, 0.012);
    const edgeMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      metalness: 0.95,
      roughness: 0.15,
    });
    const edgeMesh = new THREE.Mesh(edgeGeo, edgeMat);
    this.phoneGroup.add(edgeMesh);

    this.phoneScreenCanvas = document.createElement('canvas');
    this.phoneScreenCanvas.width = 512;
    this.phoneScreenCanvas.height = 1024;
    this.phoneScreenTexture = new THREE.CanvasTexture(this.phoneScreenCanvas);

    const screenGeo = new THREE.PlaneGeometry(0.17, 0.32);
    const screenMat = new THREE.MeshBasicMaterial({
      map: this.phoneScreenTexture,
      transparent: true,
    });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.position.z = 0.009;
    this.phoneGroup.add(screenMesh);

    this.phoneGroup.name = 'Holographic Phone';
    (this.phoneGroup as any).xb = { manipulation: true };

    this.add(this.phoneGroup);
    this.updatePhoneTexture();
  }

  private updatePhoneTexture() {
    if (!this.phoneScreenCanvas || !this.phoneScreenTexture) return;
    const ctx = this.phoneScreenCanvas.getContext('2d');
    if (!ctx) return;

    const w = this.phoneScreenCanvas.width;
    const h = this.phoneScreenCanvas.height;
    const config = autoResponder.getConfig();
    const logs = autoResponder.getLogs();

    ctx.fillStyle = '#0b141a';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = '#1f2c34';
    ctx.fillRect(0, 0, w, 110);

    ctx.fillStyle = '#00a884';
    ctx.beginPath();
    ctx.arc(60, 55, 35, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 32px sans-serif';
    ctx.fillText('M', 46, 66);

    ctx.fillStyle = '#e9edef';
    ctx.font = 'bold 30px sans-serif';
    ctx.fillText('Mamun Sender Bot', 115, 52);

    ctx.fillStyle = config.isEmergencyStopped ? '#ff3d71' : config.isSystemOnline ? '#00e676' : '#888888';
    ctx.font = '22px sans-serif';
    ctx.fillText(
      config.isEmergencyStopped ? 'Emergency Stopped' : config.isSystemOnline ? 'Online (Auto-Reply)' : 'Offline',
      115,
      88
    );

    let y = 170;
    const displayLogs = logs.slice(0, 2).reverse();

    if (displayLogs.length === 0) {
      ctx.fillStyle = '#8696a0';
      ctx.font = '24px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Ready for messages', w / 2, 450);
      ctx.textAlign = 'left';
    } else {
      displayLogs.forEach((log) => {
        ctx.fillStyle = '#005c4b';
        roundRect(ctx, 40, y, 430, 110, 18);
        ctx.fill();

        ctx.fillStyle = '#e9edef';
        ctx.font = '24px sans-serif';
        const userMsg = log.receivedMessage.length > 25 ? log.receivedMessage.slice(0, 25) + '...' : log.receivedMessage;
        ctx.fillText(userMsg, 60, y + 50);

        ctx.fillStyle = '#8696a0';
        ctx.font = '18px sans-serif';
        ctx.fillText(`${log.phoneNumber} • ${log.timestamp}`, 60, y + 90);

        y += 130;

        ctx.fillStyle = '#202c33';
        roundRect(ctx, 40, y, 430, 140, 18);
        ctx.fill();

        ctx.fillStyle = log.engine === 'AI-Gemini' ? '#ffd700' : '#00e676';
        ctx.font = 'bold 20px sans-serif';
        ctx.fillText(`[${log.engine}]`, 60, y + 36);

        ctx.fillStyle = '#e9edef';
        ctx.font = '22px sans-serif';
        const botMsg = log.systemResponse.length > 40 ? log.systemResponse.slice(0, 40) + '...' : log.systemResponse;
        ctx.fillText(botMsg, 60, y + 75);

        ctx.fillStyle = '#8696a0';
        ctx.font = '18px sans-serif';
        ctx.fillText(`${log.status} • OK`, 60, y + 115);

        y += 160;
      });
    }

    ctx.fillStyle = '#1f2c34';
    ctx.fillRect(0, h - 100, w, 100);

    ctx.fillStyle = '#2a3942';
    roundRect(ctx, 30, h - 80, 370, 60, 30);
    ctx.fill();

    ctx.fillStyle = '#8696a0';
    ctx.font = '24px sans-serif';
    ctx.fillText('Type message...', 60, h - 42);

    ctx.fillStyle = '#00a884';
    ctx.beginPath();
    ctx.arc(460, h - 50, 30, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px sans-serif';
    ctx.fillText('>', 454, h - 40);

    this.phoneScreenTexture.needsUpdate = true;
  }

  private buildSpatialUi() {
    // Only standard ASCII in spatial 3D text to prevent MSDF font atlas issues
    this.statusText = new xb.UIText({
      text: 'STATUS: ACTIVE (ONLINE)',
      style: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#00e676',
        textAlign: 'center',
      },
    });

    this.modeText = new xb.UIText({
      text: 'MODE: Fallback AI On (Gemini 2.5)',
      style: {
        fontSize: 15,
        opacity: 0.85,
        color: '#ffd700',
        textAlign: 'center',
      },
    });

    this.latestLogText = new xb.UIText({
      text: 'System ready for incoming WhatsApp messages.',
      style: {
        fontSize: 14,
        lineHeight: 1.35,
        backgroundColor: '#0a0a0c',
        padding: 12,
        borderRadius: 8,
        borderColor: '#aa8c2c',
        borderWidth: 1,
        color: '#f0f0f0',
      },
    });

    const btnSimulate = new xb.UIButton({
      label: 'Simulate Msg',
      icon: 'send',
      style: { flexGrow: 1 },
      onClick: () => {
        void autoResponder.processIncomingMessage('+8801818XXXXXX', 'আপনাদের সার্ভিস চার্জ কত?');
      },
    });

    const btnToggleEmergency = new xb.UIButton({
      label: 'Emergency Switch',
      icon: 'warning',
      style: { flexGrow: 1 },
      onClick: () => {
        autoResponder.toggleEmergencyStop();
      },
    });

    const btnCycleMode = new xb.UIButton({
      label: 'Toggle AI Mode',
      icon: 'psychology',
      style: { flexGrow: 1 },
      onClick: () => {
        const current = autoResponder.getConfig().aiStatus;
        const next = current === 'enabled' ? 'always' : current === 'always' ? 'disabled' : 'enabled';
        autoResponder.updateConfig({ aiStatus: next });
      },
    });

    this.card = new xb.UICard({
      size: { width: 0.58, height: 'auto' },
      manipulation: true,
      edge: true,
      style: {
        flexDirection: 'column',
        gap: 12,
        padding: 16,
        backgroundColor: '#141419',
        borderColor: '#d4af37',
        borderWidth: 2,
        borderRadius: 14,
      },
      children: [
        new xb.UIText({
          text: 'MAMUN SENDER',
          style: {
            fontSize: 26,
            fontWeight: 'bold',
            color: '#ffd700',
            textAlign: 'center',
          },
        }),
        this.statusText,
        this.modeText,
        this.latestLogText,
        new xb.UIPanel({
          style: { width: '100%', flexDirection: 'row', gap: 8 },
          children: [btnSimulate, btnToggleEmergency],
        }),
        btnCycleMode,
      ],
    });

    this.card.position.set(-0.35, 1.45, -1.05);
    this.card.rotation.y = 0.25;
    this.add(this.card);
  }

  private refreshState() {
    const config = autoResponder.getConfig();
    const logs = autoResponder.getLogs();

    if (this.coreMaterial) {
      if (config.isEmergencyStopped) {
        this.coreMaterial.color.set(0xff3d71);
        this.coreMaterial.emissive.set(0xff3d71);
      } else if (config.isSystemOnline) {
        this.coreMaterial.color.set(0x00e676);
        this.coreMaterial.emissive.set(0x00e676);
      } else {
        this.coreMaterial.color.set(0x888888);
        this.coreMaterial.emissive.set(0x333333);
      }
    }

    if (this.statusText) {
      if (config.isEmergencyStopped) {
        this.statusText.text = 'EMERGENCY STOPPED';
        this.statusText.style.color = '#ff3d71';
      } else if (config.isSystemOnline) {
        this.statusText.text = 'SYSTEM ACTIVE (ONLINE)';
        this.statusText.style.color = '#00e676';
      } else {
        this.statusText.text = 'SYSTEM PAUSED (OFFLINE)';
        this.statusText.style.color = '#ffaa00';
      }
    }

    if (this.modeText) {
      const modeLabel =
        config.aiStatus === 'enabled'
          ? 'Fallback AI On'
          : config.aiStatus === 'always'
            ? 'Always AI Active'
            : 'Rules Only';
      this.modeText.text = `AI Mode: ${modeLabel}`;
    }

    if (this.latestLogText) {
      const latest = logs[0];
      if (latest) {
        this.latestLogText.text = `[${latest.timestamp}] ${latest.phoneNumber} -> ${latest.engine} (${latest.status})`;
      }
    }

    this.updatePhoneTexture();
  }

  update() {
    const delta = xb.getDeltaTime();
    this.timeElapsed += delta;

    this.rings.forEach((ring, index) => {
      ring.rotation.x += (index + 1) * 0.4 * delta;
      ring.rotation.y += (index + 1) * 0.3 * delta;
    });

    this.phoneGroup.position.y = 1.35 + Math.sin(this.timeElapsed * 1.5) * 0.02;
    this.phoneGroup.rotation.y = -0.35 + Math.cos(this.timeElapsed * 0.8) * 0.03;
  }

  onSelectEnd(event: xb.SelectEvent) {
    if (event.target === this.phoneGroup || event.target === this.coreOrb) {
      void autoResponder.processIncomingMessage('+8801818XXXXXX', 'আপনাদের সার্ভিস চার্জ কত?');
    }
  }

  dispose() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
    this.phoneScreenTexture?.dispose();
    this.coreMaterial?.dispose();
  }
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}
