import * as xb from 'xrblocks';
import { SpatialCommandCenter } from './scene/SpatialCommandCenter';
import { DashboardUI } from './ui/Dashboard';

function setupApp() {
  // 1. Initialize the 2D Dashboard UI first
  const root = document.getElementById('root');
  if (root) {
    const dashboard = new DashboardUI(root);
    dashboard.init();
  }

  // 2. Setup View Mode Toggle (Dashboard vs 3D Spatial Room)
  const toggleBtn = document.getElementById('btn-toggle-view');
  const toggleLabel = document.getElementById('view-toggle-label');
  const toggleIcon = document.getElementById('view-toggle-icon');
  let is3DMode = false;

  toggleBtn?.addEventListener('click', () => {
    is3DMode = !is3DMode;
    document.body.classList.toggle('mode-3d', is3DMode);
    if (toggleLabel && toggleIcon) {
      if (is3DMode) {
        toggleIcon.textContent = '📋';
        toggleLabel.textContent = 'ড্যাশবোর্ড ভিউ (Dashboard)';
      } else {
        toggleIcon.textContent = '🌌';
        toggleLabel.textContent = '3D Spatial Room View';
      }
    }
  });

  // 3. Setup XR Blocks with fail-safe configuration
  try {
    const options = new xb.Options();
    options.setAppTitle('Mamun Sender');
    options.setAppDescription('AI WhatsApp Auto-Responder Command Center');
    options.catchScriptExceptions = true;
    // Disable intrusive default full-screen XRButton overlay so it doesn't block the dashboard with errors
    options.xrButton.enabled = false;
    options.enableHands();
    options.hands.visualization = true;
    options.enableReticles();

    const commandCenter = new SpatialCommandCenter();
    xb.add(commandCenter);

    void xb.init(options).catch((err: unknown) => {
      console.warn('XR Blocks initialization notice (continuing in desktop web mode):', err);
    });
  } catch (err: unknown) {
    console.warn('XR Blocks setup notice (desktop dashboard mode active):', err);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupApp);
} else {
  setupApp();
}
