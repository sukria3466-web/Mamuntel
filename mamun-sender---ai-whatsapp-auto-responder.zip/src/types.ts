export type AIStatusMode = 'enabled' | 'always' | 'disabled';

export type MatchType = 'contains' | 'exact';

export type EngineType = 'AI-Gemini' | 'Rule' | 'Emergency' | 'Cooldown';

export type DeliveryStatus = 'Delivered' | 'Filtered' | 'Stopped' | 'Cooldown';

export interface AutoResponderConfig {
  aiStatus: AIStatusMode;
  systemPrompt: string;
  model: string;
  cooldown: number; // in seconds
  isEmergencyStopped: boolean;
  isSystemOnline: boolean;
}

export interface KeywordRule {
  id: string;
  keyword: string;
  matchType: MatchType;
  response: string;
  active: boolean;
  hitCount: number;
  createdAt: number;
}

export interface MessageLog {
  id: string;
  timestamp: string;
  phoneNumber: string;
  receivedMessage: string;
  systemResponse: string;
  engine: EngineType;
  status: DeliveryStatus;
  responseTimeMs?: number;
}

export interface ProcessResult {
  reply: string;
  engine: EngineType;
  status: DeliveryStatus;
  ruleMatched?: KeywordRule;
  error?: string;
}
