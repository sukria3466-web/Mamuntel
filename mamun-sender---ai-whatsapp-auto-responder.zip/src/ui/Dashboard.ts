import { autoResponder } from '../services/autoResponder';

export class DashboardUI {
  private container: HTMLElement;
  private isTestingOpen: boolean = false;
  private testMessages: Array<{ text: string; sender: 'user' | 'bot'; time: string; engine?: string }> = [
    {
      text: 'আপনাদের সার্ভিস চার্জ কত?',
      sender: 'user',
      time: '11:45 PM',
    },
    {
      text: 'আমাদের মূল সার্ভিস চার্জ: বেসিক সেটআপ ৫০০৳, প্রিমিয়াম অটোমেশন ১২০০৳। বিস্তারিত জানতে আমাদের প্রতিনিধি শীঘ্রই যোগাযোগ করবেন।',
      sender: 'bot',
      time: '11:45 PM',
      engine: 'AI-Gemini',
    },
  ];

  constructor(container: HTMLElement) {
    this.container = container;
    autoResponder.subscribe(() => this.render());
  }

  init() {
    this.render();
  }

  private render() {
    const config = autoResponder.getConfig();
    const rules = autoResponder.getRules();
    const logs = autoResponder.getLogs();

    this.container.innerHTML = `
      <header>
        <div style="display: flex; align-items: center; gap: 12px;">
          <h1>MAMUN SENDER</h1>
          <span style="font-size: 0.85rem; color: #888; letter-spacing: 0.5px;">AI WhatsApp Auto-Responder</span>
        </div>
        <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap;">
          <button type="button" id="btn-toggle-test" class="btn-test-top">
            💬 টেস্ট সিমুলেটর (WhatsApp Test)
          </button>
          <div id="status-badge" class="status-badge" style="cursor: pointer;" title="ক্লিক করে সিস্টেম অন/অফ করুন">
            <div class="status-dot ${config.isSystemOnline ? '' : 'status-dot-offline'}"></div>
            <span class="${config.isSystemOnline ? 'status-text-green' : 'status-text-red'}">
              ${config.isSystemOnline ? 'সিস্টেম একটিভ (Online)' : 'সিস্টেম পজড (Offline)'}
            </span>
          </div>
          ${
            config.isEmergencyStopped
              ? '<span class="status-text-red" style="font-weight: bold; font-size: 0.9rem;">[জরুরি স্টপ সক্রিয়]</span>'
              : ''
          }
        </div>
      </header>

      <div class="grid">
        <div class="card">
          <h2>এআই রিপ্লাই ইঞ্জিন (Gemini Agent)</h2>
          <label for="ai-status">এআই অটো-রেসপন্স মোড</label>
          <select id="ai-status">
            <option value="enabled" ${config.aiStatus === 'enabled' ? 'selected' : ''}>চালু (Fallback AI On)</option>
            <option value="always" ${config.aiStatus === 'always' ? 'selected' : ''}>সর্বদা সক্রিয় (Always Use AI)</option>
            <option value="disabled" ${config.aiStatus === 'disabled' ? 'selected' : ''}>বন্ধ (Rules Only)</option>
          </select>

          <label for="prompt">সিস্টেম প্রম্পট / ট্রেইনিং নির্দেশিকা</label>
          <textarea id="prompt" rows="3" placeholder="উদা: তুমি মামুন সেন্টারের ভার্চুয়াল সহকারী। নম্রভাবে উত্তর দাও...">${escapeHtml(config.systemPrompt)}</textarea>

          <label for="model">মডেল সিলেকশন</label>
          <select id="model">
            <option value="gemini-2.5-flash (Fast & Accurate)" ${config.model.includes('flash') ? 'selected' : ''}>gemini-2.5-flash (Fast & Accurate)</option>
            <option value="gemini-2.5-pro (High Reasoning)" ${config.model.includes('pro') || config.model.includes('4') ? 'selected' : ''}>gemini-2.5-pro (High Reasoning)</option>
          </select>

          <label for="cooldown">কুলডাউন সময় (সেকেন্ড)</label>
          <input type="text" id="cooldown" value="${config.cooldown}">

          <button type="button" id="btn-save-settings">সেটিংস সেভ করুন</button>
          <div id="save-toast" class="save-toast hidden">✓ সেটিংস সফলভাবে আপডেট হয়েছে!</div>
        </div>

        <div class="card">
          <h2>স্ট্যাটিক রুল ও ট্রিগার যোগ করুন</h2>
          <label for="trigger">ইউজার মেসেজ কীওয়ার্ড</label>
          <input type="text" id="trigger" placeholder="যেমন: দাম, প্যাকেজ, অফার">

          <label for="match-type">ম্যাচ টাইপ</label>
          <select id="match-type">
            <option value="exact">Exact Match (হুবহু মিল)</option>
            <option value="contains">Contains Keyword (শব্দটি থাকলে)</option>
          </select>

          <label for="response">অটো রিপ্লাই মেসেজ</label>
          <textarea id="response" rows="3" placeholder="গ্রাহককে পাঠানো রিপ্লাই লিখুন..."></textarea>

          <button type="button" id="btn-add-rule">+ নতুন রুল যুক্ত করুন</button>
          <button type="button" id="btn-emergency-stop" class="btn-danger">
            ${config.isEmergencyStopped ? 'জরুরি স্টপ নিষ্ক্রিয় করুন (Resume)' : 'জরুরি স্টপ সুইচ'}
          </button>
        </div>
      </div>

      <!-- Active Rules Section -->
      <div class="card" style="margin-top: 24px;">
        <h2>সক্রিয় কীওয়ার্ড রুলস তালিকা (${rules.length} টি রুল)</h2>
        <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 12px;">
          ${
            rules.length === 0
              ? '<p style="color: #888; font-size: 0.9rem;">কোনো রুল সংরক্ষিত নেই। উপরের ফর্ম থেকে রুল যুক্ত করুন।</p>'
              : rules
                  .map(
                    (rule) => `
            <div style="background: #000; border: 1px solid var(--gold-muted); border-radius: 4px; padding: 10px 14px; display: flex; justify-content: space-between; align-items: center; gap: 12px;">
              <div>
                <span style="color: var(--gold-bright); font-weight: bold; margin-right: 8px;">"${escapeHtml(rule.keyword)}"</span>
                <span style="font-size: 0.75rem; color: #aaa; background: #222; padding: 2px 6px; border-radius: 3px; margin-right: 8px;">${rule.matchType === 'exact' ? 'Exact Match' : 'Contains'}</span>
                <span style="font-size: 0.75rem; color: var(--accent-green);">${rule.hitCount || 0} হিট</span>
                <div style="font-size: 0.85rem; color: #ddd; margin-top: 4px;">${escapeHtml(rule.response)}</div>
              </div>
              <button type="button" class="btn-delete-rule" data-id="${rule.id}" style="width: auto; padding: 4px 10px; margin: 0; background: #222; color: var(--accent-red); border: 1px solid #444; font-size: 0.8rem;">মুছুন</button>
            </div>
          `
                  )
                  .join('')
          }
        </div>
      </div>

      <!-- Message Logs Card -->
      <div class="card" style="margin-top: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid #333; padding-bottom: 8px;">
          <h2 style="margin-bottom: 0; border-bottom: none; padding-bottom: 0;">রিয়েল-টাইম মেসেজ ও অ্যাকশন লগ</h2>
          <div style="display: flex; gap: 8px;">
            <button type="button" id="btn-clear-logs" style="width: auto; margin: 0; padding: 6px 14px; font-size: 0.8rem; background: #222; color: #bbb; border: 1px solid #444;">লগ মুছুন</button>
            <button type="button" id="btn-export-logs" style="width: auto; margin: 0; padding: 6px 14px; font-size: 0.8rem; background: #222; color: var(--gold-bright); border: 1px solid var(--gold-muted);">CSV এক্সপোর্ট</button>
          </div>
        </div>
        <div style="overflow-x: auto;">
          <table>
            <thead>
              <tr>
                <th>সময়</th>
                <th>ফোন নম্বর</th>
                <th>প্রাপ্ত মেসেজ</th>
                <th>সিস্টেম রেসপন্স</th>
                <th>ইঞ্জিন</th>
                <th>স্ট্যাটাস</th>
              </tr>
            </thead>
            <tbody>
              ${
                logs.length === 0
                  ? `
                <tr>
                  <td>11:45 PM</td>
                  <td>+8801818XXXXXX</td>
                  <td>আপনাদের সার্ভিস চার্জ কত?</td>
                  <td>আমাদের মূল সার্ভিস চার্জ তালিকা ভিজিট করুন...</td>
                  <td><span class="tag-ai">AI-Gemini</span></td>
                  <td><span class="status-text-green">Delivered</span></td>
                </tr>
              `
                  : logs
                      .map(
                        (log) => `
                <tr>
                  <td>${escapeHtml(log.timestamp)}</td>
                  <td>${escapeHtml(log.phoneNumber)}</td>
                  <td>${escapeHtml(log.receivedMessage)}</td>
                  <td>${escapeHtml(log.systemResponse)}</td>
                  <td>
                    ${
                      log.engine === 'AI-Gemini'
                        ? '<span class="tag-ai">AI-Gemini</span>'
                        : log.engine === 'Rule'
                          ? '<span class="tag-rule">Rule</span>'
                          : '<span class="tag-err">' + escapeHtml(log.engine) + '</span>'
                    }
                  </td>
                  <td>
                    <span class="${log.status === 'Delivered' ? 'status-text-green' : 'status-text-red'}">
                      ${escapeHtml(log.status)}
                    </span>
                  </td>
                </tr>
              `
                      )
                      .join('')
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- WhatsApp Live Test Simulator Drawer -->
      <div id="test-simulator-modal" class="simulator-modal ${this.isTestingOpen ? 'open' : ''}">
        <div class="simulator-inner">
          <div class="phone-frame">
            <div class="phone-notch"></div>
            <div class="phone-header">
              <div class="phone-header-left">
                <button type="button" id="btn-close-simulator" class="btn-back">✕</button>
                <div class="avatar-circle">M</div>
                <div>
                  <div class="phone-contact-name">Mamun Sender Bot</div>
                  <div class="phone-contact-status">
                    ${config.isEmergencyStopped ? 'জরুরি স্টপ সক্রিয়' : config.isSystemOnline ? 'অনলাইন (Auto-Reply Active)' : 'অফলাইন'}
                  </div>
                </div>
              </div>
            </div>

            <div id="phone-chat-body" class="phone-chat-body">
              <div class="chat-date-chip">আজকে</div>
              ${this.testMessages
                .map(
                  (msg) => `
                <div class="chat-bubble ${msg.sender === 'user' ? 'bubble-user' : 'bubble-bot'}">
                  ${
                    msg.engine
                      ? `<div class="bubble-engine-badge ${msg.engine === 'AI-Gemini' ? 'badge-ai' : 'badge-rule'}">${escapeHtml(msg.engine)}</div>`
                      : ''
                  }
                  <div class="bubble-text">${escapeHtml(msg.text)}</div>
                  <div class="bubble-time">
                    ${msg.time}
                    ${msg.sender === 'user' ? '<span class="blue-ticks">✓✓</span>' : ''}
                  </div>
                </div>
              `
                )
                .join('')}
              <div id="bot-typing-indicator" class="bot-typing hidden">
                <span></span><span></span><span></span> <em>মামুন সেন্ডার লিখছে...</em>
              </div>
            </div>

            <!-- Quick click triggers -->
            <div class="simulator-quick-prompts">
              <button type="button" class="quick-chip" data-query="আপনাদের সার্ভিস চার্জ কত?">সার্ভিস চার্জ?</button>
              <button type="button" class="quick-chip" data-query="দাম কত?">দাম?</button>
              <button type="button" class="quick-chip" data-query="প্যাকেজ ও অফার কি?">প্যাকেজ?</button>
              <button type="button" class="quick-chip" data-query="ঠিকানা কোথায়?">ঠিকানা?</button>
            </div>

            <!-- Input Bar -->
            <div class="phone-input-bar">
              <input type="text" id="sim-phone" class="sim-phone-input" value="+8801818XXXXXX" placeholder="ফোন নম্বর" />
              <input type="text" id="sim-msg" class="sim-message-input" placeholder="মেসেজ লিখুন..." />
              <button type="button" id="btn-sim-send" class="btn-sim-send">➤</button>
            </div>
          </div>
        </div>
      </div>
    `;

    this.bindEvents();
  }

  private bindEvents() {
    // Save Settings
    const btnSave = document.getElementById('btn-save-settings');
    btnSave?.addEventListener('click', () => {
      const aiStatus = (document.getElementById('ai-status') as HTMLSelectElement)?.value as any;
      const prompt = (document.getElementById('prompt') as HTMLTextAreaElement)?.value || '';
      const model = (document.getElementById('model') as HTMLSelectElement)?.value || 'gemini-2.5-flash (Fast & Accurate)';
      const cooldownInput = (document.getElementById('cooldown') as HTMLInputElement)?.value || '60';
      const cooldown = parseInt(cooldownInput, 10);

      autoResponder.updateConfig({
        aiStatus,
        systemPrompt: prompt,
        model,
        cooldown: isNaN(cooldown) ? 60 : cooldown,
      });

      const toast = document.getElementById('save-toast');
      if (toast) {
        toast.classList.remove('hidden');
        setTimeout(() => toast.classList.add('hidden'), 2500);
      }
    });

    // Add Rule
    const btnAddRule = document.getElementById('btn-add-rule');
    btnAddRule?.addEventListener('click', () => {
      const triggerEl = document.getElementById('trigger') as HTMLInputElement;
      const matchTypeEl = document.getElementById('match-type') as HTMLSelectElement;
      const responseEl = document.getElementById('response') as HTMLTextAreaElement;

      const keyword = triggerEl?.value?.trim();
      const matchType = (matchTypeEl?.value || 'exact') as 'contains' | 'exact';
      const response = responseEl?.value?.trim();

      if (!keyword || !response) {
        alert('অনুগ্রহ করে কীওয়ার্ড এবং অটো রিপ্লাই মেসেজ উভয়ই পূরণ করুন।');
        return;
      }

      autoResponder.addRule(keyword, matchType, response);
      if (triggerEl) triggerEl.value = '';
      if (responseEl) responseEl.value = '';
    });

    // Delete Rule buttons
    const deleteButtons = document.querySelectorAll('.btn-delete-rule');
    deleteButtons.forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const id = (e.currentTarget as HTMLElement).dataset.id;
        if (id) autoResponder.deleteRule(id);
      });
    });

    // Emergency Stop Switch
    const btnEmergency = document.getElementById('btn-emergency-stop');
    btnEmergency?.addEventListener('click', () => {
      autoResponder.toggleEmergencyStop();
    });

    // Online Status Toggle
    const statusBadge = document.getElementById('status-badge');
    statusBadge?.addEventListener('click', () => {
      autoResponder.toggleOnlineStatus();
    });

    // Clear Logs
    const btnClearLogs = document.getElementById('btn-clear-logs');
    btnClearLogs?.addEventListener('click', () => {
      if (confirm('আপনি কি সমস্ত লগ মুছে ফেলতে চান?')) {
        autoResponder.clearLogs();
      }
    });

    // Export Logs CSV
    const btnExportLogs = document.getElementById('btn-export-logs');
    btnExportLogs?.addEventListener('click', () => {
      const logs = autoResponder.getLogs();
      let csv = 'Timestamp,PhoneNumber,ReceivedMessage,SystemResponse,Engine,Status\n';
      logs.forEach((l) => {
        csv += `"${l.timestamp}","${l.phoneNumber}","${l.receivedMessage.replace(/"/g, '""')}","${l.systemResponse.replace(/"/g, '""')}","${l.engine}","${l.status}"\n`;
      });
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `mamun-sender-logs-${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    });

    // Simulator Drawer Toggle
    const btnToggleTest = document.getElementById('btn-toggle-test');
    btnToggleTest?.addEventListener('click', () => {
      this.isTestingOpen = !this.isTestingOpen;
      const modal = document.getElementById('test-simulator-modal');
      modal?.classList.toggle('open', this.isTestingOpen);
    });

    const btnCloseSimulator = document.getElementById('btn-close-simulator');
    btnCloseSimulator?.addEventListener('click', () => {
      this.isTestingOpen = false;
      const modal = document.getElementById('test-simulator-modal');
      modal?.classList.remove('open');
    });

    // Simulator Quick chips
    const quickChips = document.querySelectorAll('.quick-chip');
    quickChips.forEach((chip) => {
      chip.addEventListener('click', (e) => {
        const query = (e.currentTarget as HTMLElement).dataset.query;
        if (query) {
          const simInput = document.getElementById('sim-msg') as HTMLInputElement;
          if (simInput) {
            simInput.value = query;
            this.handleSimSend();
          }
        }
      });
    });

    // Simulator Send
    const btnSimSend = document.getElementById('btn-sim-send');
    const simMsgInput = document.getElementById('sim-msg') as HTMLInputElement;

    btnSimSend?.addEventListener('click', () => this.handleSimSend());
    simMsgInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        this.handleSimSend();
      }
    });
  }

  private async handleSimSend() {
    const phoneInput = document.getElementById('sim-phone') as HTMLInputElement;
    const msgInput = document.getElementById('sim-msg') as HTMLInputElement;
    const typingIndicator = document.getElementById('bot-typing-indicator');

    const phone = phoneInput?.value?.trim() || '+8801818XXXXXX';
    const message = msgInput?.value?.trim();

    if (!message) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    this.testMessages.push({
      text: message,
      sender: 'user',
      time: timeStr,
    });
    msgInput.value = '';

    this.updateChatView();
    typingIndicator?.classList.remove('hidden');

    try {
      const result = await autoResponder.processIncomingMessage(phone, message);
      typingIndicator?.classList.add('hidden');

      this.testMessages.push({
        text: result.reply,
        sender: 'bot',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        engine: result.engine,
      });

      this.updateChatView();
    } catch {
      typingIndicator?.classList.add('hidden');
    }
  }

  private updateChatView() {
    const chatBody = document.getElementById('phone-chat-body');
    if (!chatBody) return;

    chatBody.innerHTML = `
      <div class="chat-date-chip">আজকে</div>
      ${this.testMessages
        .map(
          (msg) => `
        <div class="chat-bubble ${msg.sender === 'user' ? 'bubble-user' : 'bubble-bot'}">
          ${
            msg.engine
              ? `<div class="bubble-engine-badge ${msg.engine === 'AI-Gemini' ? 'badge-ai' : 'badge-rule'}">${escapeHtml(msg.engine)}</div>`
              : ''
          }
          <div class="bubble-text">${escapeHtml(msg.text)}</div>
          <div class="bubble-time">
            ${msg.time}
            ${msg.sender === 'user' ? '<span class="blue-ticks">✓✓</span>' : ''}
          </div>
        </div>
      `
        )
        .join('')}
      <div id="bot-typing-indicator" class="bot-typing hidden">
        <span></span><span></span><span></span> <em>মামুন সেন্ডার লিখছে...</em>
      </div>
    `;

    chatBody.scrollTop = chatBody.scrollHeight;
  }
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
