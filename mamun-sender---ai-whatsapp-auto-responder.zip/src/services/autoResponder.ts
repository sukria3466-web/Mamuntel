import {
  AutoResponderConfig,
  KeywordRule,
  MessageLog,
  ProcessResult,
} from '../types';
import { sounds } from './soundEffects';

const STORAGE_KEYS = {
  CONFIG: 'mamun_sender_config',
  RULES: 'mamun_sender_rules',
  LOGS: 'mamun_sender_logs',
};

const DEFAULT_CONFIG: AutoResponderConfig = {
  aiStatus: 'enabled',
  systemPrompt:
    'তুমি মামুন সেন্টারের ভার্চুয়াল সহকারী। গ্রাহকদের অত্যন্ত নম্র ও পেশাদারভাবে উত্তর দাও। সার্ভিস চার্জ, নতুন প্যাকেজ, ঠিকানা এবং সাপোর্ট সম্পর্কে সঠিক তথ্য প্রদান করো। প্রয়োজনে বলো আমাদের হটলাইন +৮৮০১৮১৮০০০০০০ চালু আছে।',
  model: 'gemini-2.5-flash (Fast & Accurate)',
  cooldown: 60,
  isEmergencyStopped: false,
  isSystemOnline: true,
};

const DEFAULT_RULES: KeywordRule[] = [
  {
    id: 'rule-1',
    keyword: 'সার্ভিস চার্জ',
    matchType: 'contains',
    response:
      'আমাদের মূল সার্ভিস চার্জ: বেসিক সেটআপ ৫০০৳, প্রিমিয়াম অটোমেশন ১২০০৳। বিস্তারিত জানতে আমাদের প্রতিনিধি শীঘ্রই যোগাযোগ করবেন।',
    active: true,
    hitCount: 3,
    createdAt: Date.now() - 3600000,
  },
  {
    id: 'rule-2',
    keyword: 'দাম',
    matchType: 'contains',
    response:
      'সকল প্যাকেজের মূল্য তালিকা: ১. স্টার্টার: ৯৯৯৳/মাস, ২. বিজনেস প্রো: ২৪৯৯৳/মাস। আপনার ব্যবসার জন্য কোনটি প্রয়োজন জানাবেন?',
    active: true,
    hitCount: 5,
    createdAt: Date.now() - 7200000,
  },
  {
    id: 'rule-3',
    keyword: 'প্যাকেজ',
    matchType: 'contains',
    response:
      'মামুন সেন্টারের স্পেশাল প্যাকেজে রয়েছে আনলিমিটেড হোয়াটসঅ্যাপ অটোমেশন ও এআই চ্যাটবট সাপোর্ট। আজকের অফারে থাকছে ২৫% ছাড়!',
    active: true,
    hitCount: 2,
    createdAt: Date.now() - 10800000,
  },
  {
    id: 'rule-4',
    keyword: 'অফার',
    matchType: 'contains',
    response:
      'ধামাকা অফার! এই সপ্তাহের সাবস্ক্রিপশনে পাচ্ছেন ফ্রি সেটআপ এবং প্রথম ১৫ দিন প্রিমিয়াম এআই ট্রায়াল।',
    active: true,
    hitCount: 4,
    createdAt: Date.now() - 14400000,
  },
  {
    id: 'rule-5',
    keyword: 'ঠিকানা',
    matchType: 'contains',
    response:
      'আমাদের প্রধান কার্যালয়: মামুন সেন্টার, রোড # ৪, ধানমন্ডি, ঢাকা-১২০৫। সকাল ১০টা থেকে রাত ৮টা পর্যন্ত খোলা।',
    active: true,
    hitCount: 1,
    createdAt: Date.now() - 18000000,
  },
];

const DEFAULT_LOGS: MessageLog[] = [
  {
    id: 'log-1',
    timestamp: '11:45 PM',
    phoneNumber: '+8801818XXXXXX',
    receivedMessage: 'আপনাদের সার্ভিস চার্জ কত?',
    systemResponse: 'আমাদের মূল সার্ভিস চার্জ তালিকা ভিজিট করুন...',
    engine: 'AI-Gemini',
    status: 'Delivered',
    responseTimeMs: 340,
  },
  {
    id: 'log-2',
    timestamp: '11:40 PM',
    phoneNumber: '+8801712YYYYYY',
    receivedMessage: 'নতুন কোনো অফার আছে কি?',
    systemResponse: 'ধামাকা অফার! এই সপ্তাহের সাবস্ক্রিপশনে পাচ্ছেন ফ্রি সেটআপ...',
    engine: 'Rule',
    status: 'Delivered',
    responseTimeMs: 25,
  },
];

// In-memory memory store fallback if localStorage is blocked
const memoryStore: Record<string, string> = {};

function safeGetItem(key: string): string | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage.getItem(key);
    }
  } catch {
    // Fall back to memoryStore
  }
  return memoryStore[key] ?? null;
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  } catch {
    // Fall back to memoryStore
  }
  memoryStore[key] = value;
}

class AutoResponderService {
  private config: AutoResponderConfig = { ...DEFAULT_CONFIG };
  private rules: KeywordRule[] = [...DEFAULT_RULES];
  private logs: MessageLog[] = [...DEFAULT_LOGS];
  private lastReplyTimeByPhone: Map<string, number> = new Map();
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const cfg = safeGetItem(STORAGE_KEYS.CONFIG);
      if (cfg) this.config = { ...DEFAULT_CONFIG, ...JSON.parse(cfg) };

      const rls = safeGetItem(STORAGE_KEYS.RULES);
      if (rls) this.rules = JSON.parse(rls);

      const lgs = safeGetItem(STORAGE_KEYS.LOGS);
      if (lgs) this.logs = JSON.parse(lgs);
    } catch {
      // Use defaults if parse fails
    }
  }

  private saveToStorage() {
    try {
      safeSetItem(STORAGE_KEYS.CONFIG, JSON.stringify(this.config));
      safeSetItem(STORAGE_KEYS.RULES, JSON.stringify(this.rules));
      safeSetItem(STORAGE_KEYS.LOGS, JSON.stringify(this.logs));
    } catch {
      // Silently continue
    }
    this.notify();
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    for (const listener of this.listeners) {
      try {
        listener();
      } catch {
        // Safe notify
      }
    }
  }

  getConfig(): AutoResponderConfig {
    return { ...this.config };
  }

  updateConfig(updates: Partial<AutoResponderConfig>) {
    this.config = { ...this.config, ...updates };
    this.saveToStorage();
  }

  toggleEmergencyStop(): boolean {
    this.config.isEmergencyStopped = !this.config.isEmergencyStopped;
    if (this.config.isEmergencyStopped) {
      sounds.playEmergency();
    } else {
      sounds.playClick();
    }
    this.saveToStorage();
    return this.config.isEmergencyStopped;
  }

  toggleOnlineStatus(): boolean {
    this.config.isSystemOnline = !this.config.isSystemOnline;
    sounds.playClick();
    this.saveToStorage();
    return this.config.isSystemOnline;
  }

  getRules(): KeywordRule[] {
    return [...this.rules];
  }

  addRule(keyword: string, matchType: 'contains' | 'exact', response: string): KeywordRule {
    const newRule: KeywordRule = {
      id: `rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      keyword: keyword.trim(),
      matchType,
      response: response.trim(),
      active: true,
      hitCount: 0,
      createdAt: Date.now(),
    };
    this.rules.unshift(newRule);
    sounds.playClick();
    this.saveToStorage();
    return newRule;
  }

  deleteRule(ruleId: string) {
    this.rules = this.rules.filter((r) => r.id !== ruleId);
    sounds.playClick();
    this.saveToStorage();
  }

  toggleRuleActive(ruleId: string) {
    const rule = this.rules.find((r) => r.id === ruleId);
    if (rule) {
      rule.active = !rule.active;
      sounds.playClick();
      this.saveToStorage();
    }
  }

  getLogs(): MessageLog[] {
    return [...this.logs];
  }

  clearLogs() {
    this.logs = [];
    sounds.playClick();
    this.saveToStorage();
  }

  async processIncomingMessage(phoneNumber: string, rawMessage: string): Promise<ProcessResult> {
    const startTime = performance.now();
    const cleanPhone = phoneNumber.trim() || '+8801818XXXXXX';
    const cleanMsg = rawMessage.trim();
    sounds.playIncoming();

    // 1. Check System Online
    if (!this.config.isSystemOnline) {
      const result: ProcessResult = {
        reply: '[সিস্টেম অফলাইন] বর্তমানে মামুন সেন্ডার অটো-রেসপন্ডার বন্ধ রয়েছে।',
        engine: 'Emergency',
        status: 'Stopped',
      };
      this.recordLog(cleanPhone, cleanMsg, result.reply, result.engine, result.status, startTime);
      return result;
    }

    // 2. Check Emergency Stop Switch
    if (this.config.isEmergencyStopped) {
      const result: ProcessResult = {
        reply: '[জরুরি স্টপ সক্রিয়] জরুরি স্টপ অন থাকায় অটো-রিপ্লাই স্থগিত করা হয়েছে।',
        engine: 'Emergency',
        status: 'Stopped',
      };
      this.recordLog(cleanPhone, cleanMsg, result.reply, result.engine, result.status, startTime);
      return result;
    }

    // 3. Check Cooldown
    const now = Date.now();
    const lastTime = this.lastReplyTimeByPhone.get(cleanPhone) || 0;
    const cooldownMs = (this.config.cooldown || 60) * 1000;
    if (now - lastTime < cooldownMs && lastTime > 0) {
      const remainingSec = Math.ceil((cooldownMs - (now - lastTime)) / 1000);
      const result: ProcessResult = {
        reply: `[কুলডাউন সক্রিয়] এই নম্বরে ইতিমধ্যে রিপ্লাই দেওয়া হয়েছে। অনুগ্রহ করে ${remainingSec} সেকেন্ড অপেক্ষা করুন।`,
        engine: 'Cooldown',
        status: 'Cooldown',
      };
      this.recordLog(cleanPhone, cleanMsg, result.reply, result.engine, result.status, startTime);
      return result;
    }

    // 4. Check Keyword Rules (if not in 'always' AI mode)
    if (this.config.aiStatus !== 'always') {
      const lowerMsg = cleanMsg.toLowerCase();
      const matchedRule = this.rules.find((r) => {
        if (!r.active) return false;
        const kw = r.keyword.toLowerCase();
        if (r.matchType === 'exact') {
          return lowerMsg === kw;
        } else {
          return lowerMsg.includes(kw);
        }
      });

      if (matchedRule) {
        matchedRule.hitCount = (matchedRule.hitCount || 0) + 1;
        this.lastReplyTimeByPhone.set(cleanPhone, Date.now());
        sounds.playOutgoing();

        const result: ProcessResult = {
          reply: matchedRule.response,
          engine: 'Rule',
          status: 'Delivered',
          ruleMatched: matchedRule,
        };
        this.recordLog(cleanPhone, cleanMsg, result.reply, result.engine, result.status, startTime);
        this.saveToStorage();
        return result;
      }
    }

    // 5. If Mode is 'disabled' (Rules only) and no rule matched
    if (this.config.aiStatus === 'disabled') {
      const result: ProcessResult = {
        reply: 'বার্তাটি প্রাপ্ত হয়েছে। আপনার বার্তার সাথে কোনো স্ট্যাটিক রুল মেলেনি (AI Mode: Rules Only)। একজন প্রতিনিধি যোগাযোগ করবেন।',
        engine: 'Rule',
        status: 'Filtered',
      };
      this.recordLog(cleanPhone, cleanMsg, result.reply, result.engine, result.status, startTime);
      return result;
    }

    // 6. Gemini AI Agent Fallback or Always Mode
    try {
      const apiResponse = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: cleanMsg,
          systemPrompt: this.config.systemPrompt,
          model: this.config.model,
        }),
      });

      const data = await apiResponse.json();
      const aiReply =
        data.reply ||
        'ধন্যবাদ আপনার বার্তার জন্য। মামুন সেন্টারের সহকারী আপনাকে শীঘ্রই সহায়তা করবেন।';

      this.lastReplyTimeByPhone.set(cleanPhone, Date.now());
      sounds.playOutgoing();

      const result: ProcessResult = {
        reply: aiReply,
        engine: 'AI-Gemini',
        status: 'Delivered',
      };
      this.recordLog(cleanPhone, cleanMsg, result.reply, result.engine, result.status, startTime);
      return result;
    } catch {
      const fallbackReply =
        'আসসালামু আলাইকুম! মামুন সেন্টারে আপনাকে স্বাগতম। আপনার বার্তাটি সফলভাবে প্রাপ্ত হয়েছে, আমাদের প্রতিনিধি দ্রুত যোগাযোগ করবেন।';
      this.lastReplyTimeByPhone.set(cleanPhone, Date.now());
      sounds.playOutgoing();

      const result: ProcessResult = {
        reply: fallbackReply,
        engine: 'AI-Gemini',
        status: 'Delivered',
      };
      this.recordLog(cleanPhone, cleanMsg, result.reply, result.engine, result.status, startTime);
      return result;
    }
  }

  private recordLog(
    phoneNumber: string,
    receivedMessage: string,
    systemResponse: string,
    engine: MessageLog['engine'],
    status: MessageLog['status'],
    startTime: number
  ) {
    const elapsed = Math.round(performance.now() - startTime);
    const date = new Date();
    const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newLog: MessageLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: timeStr,
      phoneNumber,
      receivedMessage,
      systemResponse,
      engine,
      status,
      responseTimeMs: Math.max(12, elapsed),
    };

    this.logs.unshift(newLog);
    if (this.logs.length > 100) {
      this.logs = this.logs.slice(0, 100);
    }
    this.saveToStorage();
  }
}

export const autoResponder = new AutoResponderService();
